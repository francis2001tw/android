package me.rerere.rikkahub.data.api

interface RikkaHubAPI {

}