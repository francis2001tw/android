---
name: Bug Report
about: 报告APP Bug或者崩溃
title: ''
labels: ''
assignees: ''

---

## 问题描述 | Problem Description

在这里描述你的问题。  
Describe your issue here.

## 截图 | Screenshot

在这里放置相关截图或者录屏。  
Attach relevant screenshots or screen recordings here.

## 版本信息 | Version Information

APP版本: （例如：v1.2.3）  
App Version: (e.g. v1.2.3)

安卓版本: （例如：Android 12）  
Android Version: (e.g. Android 12)

手机型号: （例如：小米11）  
Device Model: (e.g. Xiaomi 11)
